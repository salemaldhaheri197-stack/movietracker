// Client tools for the ElevenLabs agent. Pass an object like this into
// useConversation({ clientTools }) (see AssistantScreen.js) so the agent can
// answer things like "have I watched Breaking Bad season 2?" or act on your
// behalf, e.g. "mark The Bear S1E3 as watched".
//
// Each function's name here must match a "Client tool" you define in the
// ElevenLabs agent dashboard (Tools tab), with matching parameter names.

import { searchMulti, getTvDetails, getSeasonDetails } from '../services/tmdb';
import * as api from '../services/api';

export function buildAgentTools({ token, watched }) {
  return {
    async search_titles({ query }) {
      const data = await searchMulti(query);
      return (data.results || [])
        .filter((r) => r.media_type === 'movie' || r.media_type === 'tv')
        .slice(0, 5)
        .map((r) => ({
          id: r.id,
          type: r.media_type,
          title: r.title || r.name,
          year: (r.release_date || r.first_air_date || '').slice(0, 4),
        }));
    },

    async check_episode_watched({ tv_id, season_number, episode_number }) {
      return { watched: watched.isEpisodeWatched(tv_id, season_number, episode_number) };
    },

    async mark_episode_watched({ tv_id, show_name, season_number, episode_number }) {
      await api.setEpisodeWatched(
        token,
        { tvId: tv_id, showName: show_name, seasonNumber: season_number, episodeNumber: episode_number },
        true
      );
      await watched.refresh();
      return { success: true };
    },

    async mark_movie_watched({ tmdb_id, title, poster_path }) {
      await api.setMovieWatched(token, { id: tmdb_id, title, poster_path }, true);
      await watched.refresh();
      return { success: true };
    },

    async get_show_progress({ tv_id }) {
      const show = await getTvDetails(tv_id);
      const totalEpisodes = show.number_of_episodes;
      const watchedCount = watched.episodes.filter((e) => e.tv_id === tv_id).length;
      return { show_name: show.name, total_episodes: totalEpisodes, watched_episodes: watchedCount };
    },
  };
}
