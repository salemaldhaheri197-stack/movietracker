import React from 'react';
import { Image, Pressable, StyleSheet, Text, View } from 'react-native';
import { posterUrl } from '../services/tmdb';

export default function PosterCard({ item, onPress }) {
  const title = item.title || item.name;
  const year = (item.release_date || item.first_air_date || '').slice(0, 4);
  const uri = posterUrl(item.poster_path);

  return (
    <Pressable style={styles.card} onPress={onPress}>
      {uri ? (
        <Image source={{ uri }} style={styles.poster} />
      ) : (
        <View style={[styles.poster, styles.posterFallback]}>
          <Text style={styles.fallbackText}>{title}</Text>
        </View>
      )}
      <Text style={styles.title} numberOfLines={1}>{title}</Text>
      {year ? <Text style={styles.year}>{year}</Text> : null}
    </Pressable>
  );
}

const styles = StyleSheet.create({
  card: { width: 110, marginRight: 12 },
  poster: { width: 110, height: 165, borderRadius: 8, backgroundColor: '#1c1c1e' },
  posterFallback: { justifyContent: 'center', alignItems: 'center', padding: 6 },
  fallbackText: { color: '#8e8e93', fontSize: 12, textAlign: 'center' },
  title: { color: '#fff', fontSize: 13, marginTop: 6, fontWeight: '500' },
  year: { color: '#8e8e93', fontSize: 12 },
});
