import React, { useEffect, useState } from 'react';
import { FlatList, RefreshControl, ScrollView, StyleSheet, Text, View } from 'react-native';
import PosterCard from '../components/PosterCard';
import { getTrending } from '../services/tmdb';

function Row({ title, data, onPressItem }) {
  if (!data.length) return null;
  return (
    <View style={styles.row}>
      <Text style={styles.rowTitle}>{title}</Text>
      <FlatList
        data={data}
        horizontal
        showsHorizontalScrollIndicator={false}
        keyExtractor={(item) => `${item.media_type}-${item.id}`}
        renderItem={({ item }) => <PosterCard item={item} onPress={() => onPressItem(item)} />}
        contentContainerStyle={{ paddingLeft: 16 }}
      />
    </View>
  );
}

export default function HomeScreen({ navigation }) {
  const [trendingToday, setTrendingToday] = useState([]);
  const [trendingWeek, setTrendingWeek] = useState([]);
  const [refreshing, setRefreshing] = useState(false);

  async function load() {
    const [day, week] = await Promise.all([getTrending('all', 'day'), getTrending('all', 'week')]);
    setTrendingToday((day.results || []).filter((i) => i.media_type !== 'person'));
    setTrendingWeek((week.results || []).filter((i) => i.media_type !== 'person'));
  }

  useEffect(() => { load(); }, []);

  function openItem(item) {
    if (item.media_type === 'tv') {
      navigation.navigate('TVDetail', { id: item.id });
    } else {
      navigation.navigate('MovieDetail', { id: item.id });
    }
  }

  return (
    <ScrollView
      style={styles.container}
      refreshControl={
        <RefreshControl
          refreshing={refreshing}
          onRefresh={async () => { setRefreshing(true); await load(); setRefreshing(false); }}
          tintColor="#fff"
        />
      }
    >
      <Text style={styles.header}>Movie Tracker</Text>
      <Row title="Trending Today" data={trendingToday} onPressItem={openItem} />
      <Row title="Trending This Week" data={trendingWeek} onPressItem={openItem} />
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#000' },
  header: { color: '#fff', fontSize: 26, fontWeight: '700', padding: 16 },
  row: { marginBottom: 20 },
  rowTitle: { color: '#fff', fontSize: 18, fontWeight: '600', marginLeft: 16, marginBottom: 10 },
});
