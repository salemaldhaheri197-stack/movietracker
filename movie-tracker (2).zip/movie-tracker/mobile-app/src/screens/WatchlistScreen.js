import React, { useMemo } from 'react';
import { FlatList, Image, Pressable, RefreshControl, SectionList, StyleSheet, Text, View } from 'react-native';
import { posterUrl } from '../services/tmdb';
import { useWatched } from '../context/WatchedContext';

export default function WatchlistScreen({ navigation }) {
  const { movies, episodes, refresh } = useWatched();
  const [refreshing, setRefreshing] = React.useState(false);

  const showsGrouped = useMemo(() => {
    const map = new Map();
    for (const ep of episodes) {
      if (!map.has(ep.tv_id)) {
        map.set(ep.tv_id, { tvId: ep.tv_id, showName: ep.show_name, episodes: [] });
      }
      map.get(ep.tv_id).episodes.push(ep);
    }
    return Array.from(map.values());
  }, [episodes]);

  const sections = [
    { title: 'Watched Movies', data: movies.length ? [movies] : [] },
    { title: 'TV Shows in Progress', data: showsGrouped.length ? [showsGrouped] : [] },
  ];

  return (
    <SectionList
      style={styles.container}
      sections={sections}
      keyExtractor={(_, i) => String(i)}
      refreshControl={
        <RefreshControl
          refreshing={refreshing}
          onRefresh={async () => { setRefreshing(true); await refresh(); setRefreshing(false); }}
          tintColor="#fff"
        />
      }
      renderSectionHeader={({ section }) =>
        (section.data.length ? <Text style={styles.sectionTitle}>{section.title}</Text> : null)
      }
      renderItem={({ item, section }) => {
        if (section.title === 'Watched Movies') {
          return (
            <FlatList
              data={item}
              horizontal
              showsHorizontalScrollIndicator={false}
              keyExtractor={(m) => String(m.tmdb_id)}
              contentContainerStyle={{ paddingLeft: 16 }}
              renderItem={({ item: movie }) => (
                <Pressable
                  style={styles.moviePoster}
                  onPress={() => navigation.navigate('MovieDetail', { id: movie.tmdb_id })}
                >
                  <Image source={{ uri: posterUrl(movie.poster_path) }} style={styles.poster} />
                  <Text style={styles.movieTitle} numberOfLines={1}>{movie.title}</Text>
                </Pressable>
              )}
            />
          );
        }
        return (
          <View>
            {item.map((show) => (
              <Pressable
                key={show.tvId}
                style={styles.showRow}
                onPress={() => navigation.navigate('TVDetail', { id: show.tvId })}
              >
                <Text style={styles.showName}>{show.showName}</Text>
                <Text style={styles.showMeta}>{show.episodes.length} episode{show.episodes.length !== 1 ? 's' : ''} watched</Text>
              </Pressable>
            ))}
          </View>
        );
      }}
      ListEmptyComponent={<Text style={styles.empty}>Nothing tracked yet — go watch something!</Text>}
    />
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#000' },
  sectionTitle: { color: '#fff', fontSize: 18, fontWeight: '600', margin: 16 },
  moviePoster: { width: 110, marginRight: 12 },
  poster: { width: 110, height: 165, borderRadius: 8, backgroundColor: '#1c1c1e' },
  movieTitle: { color: '#fff', fontSize: 13, marginTop: 6 },
  showRow: { paddingHorizontal: 16, paddingVertical: 10, borderBottomColor: '#1c1c1e', borderBottomWidth: 1 },
  showName: { color: '#fff', fontSize: 16, fontWeight: '500' },
  showMeta: { color: '#8e8e93', fontSize: 13, marginTop: 2 },
  empty: { color: '#8e8e93', textAlign: 'center', marginTop: 60 },
});
