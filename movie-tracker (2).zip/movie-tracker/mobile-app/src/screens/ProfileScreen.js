import React from 'react';
import { Pressable, StyleSheet, Text, View } from 'react-native';
import { useAuth } from '../context/AuthContext';
import { useWatched } from '../context/WatchedContext';

export default function ProfileScreen({ navigation }) {
  const { user, logout } = useAuth();
  const { movies, episodes } = useWatched();

  return (
    <View style={styles.container}>
      <Text style={styles.email}>{user?.email}</Text>

      <View style={styles.statsRow}>
        <View style={styles.stat}>
          <Text style={styles.statNumber}>{movies.length}</Text>
          <Text style={styles.statLabel}>Movies watched</Text>
        </View>
        <View style={styles.stat}>
          <Text style={styles.statNumber}>{episodes.length}</Text>
          <Text style={styles.statLabel}>Episodes watched</Text>
        </View>
      </View>

      <Pressable style={styles.assistantButton} onPress={() => navigation.navigate('Assistant')}>
        <Text style={styles.assistantButtonText}>🎙️ Talk to Assistant</Text>
      </Pressable>

      <Pressable style={styles.logoutButton} onPress={logout}>
        <Text style={styles.logoutText}>Log Out</Text>
      </Pressable>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#000', padding: 24, paddingTop: 40 },
  email: { color: '#fff', fontSize: 20, fontWeight: '600', marginBottom: 24 },
  statsRow: { flexDirection: 'row', marginBottom: 32 },
  stat: { marginRight: 32 },
  statNumber: { color: '#fff', fontSize: 28, fontWeight: '700' },
  statLabel: { color: '#8e8e93', fontSize: 13, marginTop: 2 },
  assistantButton: {
    backgroundColor: '#1c1c1e', borderRadius: 10, padding: 14, alignItems: 'center', marginBottom: 12,
  },
  assistantButtonText: { color: '#fff', fontWeight: '600', fontSize: 16 },
  logoutButton: { padding: 14, alignItems: 'center' },
  logoutText: { color: '#ff453a', fontWeight: '600' },
});
