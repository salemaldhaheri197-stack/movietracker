import React, { useEffect, useState } from 'react';
import { ActivityIndicator, FlatList, Image, Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import { getMovieDetails, posterUrl } from '../services/tmdb';
import { useWatched } from '../context/WatchedContext';

export default function MovieDetailScreen({ route }) {
  const { id } = route.params;
  const [movie, setMovie] = useState(null);
  const { isMovieWatched, toggleMovie } = useWatched();

  useEffect(() => {
    getMovieDetails(id).then(setMovie);
  }, [id]);

  if (!movie) {
    return (
      <View style={styles.loading}>
        <ActivityIndicator color="#fff" />
      </View>
    );
  }

  const watched = isMovieWatched(movie.id);
  const cast = movie.credits?.cast?.slice(0, 15) || [];
  const genres = (movie.genres || []).map((g) => g.name).join(' · ');

  return (
    <ScrollView style={styles.container}>
      <Image source={{ uri: posterUrl(movie.backdrop_path, 'w780') }} style={styles.backdrop} />
      <View style={styles.body}>
        <Text style={styles.title}>{movie.title}</Text>
        <Text style={styles.meta}>
          {movie.release_date?.slice(0, 4)} · {movie.runtime ? `${movie.runtime} min` : ''} · ⭐ {movie.vote_average?.toFixed(1)}
        </Text>
        {genres ? <Text style={styles.genres}>{genres}</Text> : null}

        <Pressable style={[styles.watchButton, watched && styles.watchButtonActive]} onPress={() => toggleMovie(movie)}>
          <Text style={styles.watchButtonText}>{watched ? '✓ Watched' : 'Mark as Watched'}</Text>
        </Pressable>

        <Text style={styles.overview}>{movie.overview}</Text>

        {cast.length > 0 && (
          <>
            <Text style={styles.sectionTitle}>Cast</Text>
            <FlatList
              data={cast}
              horizontal
              showsHorizontalScrollIndicator={false}
              keyExtractor={(item) => String(item.credit_id)}
              renderItem={({ item }) => (
                <View style={styles.castCard}>
                  <Image
                    source={{ uri: posterUrl(item.profile_path, 'w185') }}
                    style={styles.castPhoto}
                  />
                  <Text style={styles.castName} numberOfLines={1}>{item.name}</Text>
                  <Text style={styles.castRole} numberOfLines={1}>{item.character}</Text>
                </View>
              )}
            />
          </>
        )}
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#000' },
  loading: { flex: 1, backgroundColor: '#000', justifyContent: 'center' },
  backdrop: { width: '100%', height: 220, backgroundColor: '#1c1c1e' },
  body: { padding: 16 },
  title: { color: '#fff', fontSize: 24, fontWeight: '700' },
  meta: { color: '#8e8e93', fontSize: 14, marginTop: 4 },
  genres: { color: '#8e8e93', fontSize: 13, marginTop: 4 },
  watchButton: {
    backgroundColor: '#1c1c1e', borderRadius: 10, padding: 12,
    alignItems: 'center', marginTop: 16,
  },
  watchButtonActive: { backgroundColor: '#2e7d32' },
  watchButtonText: { color: '#fff', fontWeight: '600' },
  overview: { color: '#d1d1d6', fontSize: 15, lineHeight: 22, marginTop: 16 },
  sectionTitle: { color: '#fff', fontSize: 18, fontWeight: '600', marginTop: 24, marginBottom: 10 },
  castCard: { width: 90, marginRight: 12 },
  castPhoto: { width: 90, height: 120, borderRadius: 8, backgroundColor: '#1c1c1e' },
  castName: { color: '#fff', fontSize: 13, marginTop: 6, fontWeight: '500' },
  castRole: { color: '#8e8e93', fontSize: 12 },
});
