import React, { useEffect, useState } from 'react';
import { ActivityIndicator, FlatList, Image, Pressable, StyleSheet, Text, View } from 'react-native';
import { getSeasonDetails, posterUrl } from '../services/tmdb';
import { useWatched } from '../context/WatchedContext';

export default function SeasonScreen({ route }) {
  const { tvId, showName, seasonNumber, seasonName } = route.params;
  const [season, setSeason] = useState(null);
  const { isEpisodeWatched, toggleEpisode } = useWatched();

  useEffect(() => {
    getSeasonDetails(tvId, seasonNumber).then(setSeason);
  }, [tvId, seasonNumber]);

  if (!season) {
    return (
      <View style={styles.loading}>
        <ActivityIndicator color="#fff" />
      </View>
    );
  }

  return (
    <FlatList
      style={styles.container}
      data={season.episodes || []}
      keyExtractor={(item) => String(item.id)}
      ListHeaderComponent={<Text style={styles.header}>{seasonName}</Text>}
      renderItem={({ item }) => {
        const watched = isEpisodeWatched(tvId, seasonNumber, item.episode_number);
        return (
          <View style={styles.episodeRow}>
            <Image source={{ uri: posterUrl(item.still_path, 'w300') }} style={styles.still} />
            <View style={styles.episodeInfo}>
              <Text style={styles.episodeTitle} numberOfLines={2}>
                {item.episode_number}. {item.name}
              </Text>
              <Text style={styles.episodeMeta}>{item.air_date} · ⭐ {item.vote_average?.toFixed(1)}</Text>
              <Text style={styles.episodeOverview} numberOfLines={3}>{item.overview}</Text>
              <Pressable
                style={[styles.watchButton, watched && styles.watchButtonActive]}
                onPress={() =>
                  toggleEpisode({
                    tvId,
                    showName,
                    seasonNumber,
                    episodeNumber: item.episode_number,
                  })
                }
              >
                <Text style={styles.watchButtonText}>{watched ? '✓ Watched' : 'Mark Watched'}</Text>
              </Pressable>
            </View>
          </View>
        );
      }}
    />
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#000' },
  loading: { flex: 1, backgroundColor: '#000', justifyContent: 'center' },
  header: { color: '#fff', fontSize: 22, fontWeight: '700', padding: 16 },
  episodeRow: { flexDirection: 'row', paddingHorizontal: 16, marginBottom: 20 },
  still: { width: 130, height: 80, borderRadius: 8, backgroundColor: '#1c1c1e' },
  episodeInfo: { flex: 1, marginLeft: 12 },
  episodeTitle: { color: '#fff', fontSize: 15, fontWeight: '600' },
  episodeMeta: { color: '#8e8e93', fontSize: 12, marginTop: 2 },
  episodeOverview: { color: '#d1d1d6', fontSize: 13, marginTop: 4, lineHeight: 18 },
  watchButton: {
    backgroundColor: '#1c1c1e', borderRadius: 8, paddingVertical: 6,
    alignItems: 'center', marginTop: 8, alignSelf: 'flex-start', paddingHorizontal: 12,
  },
  watchButtonActive: { backgroundColor: '#2e7d32' },
  watchButtonText: { color: '#fff', fontSize: 12, fontWeight: '600' },
});
