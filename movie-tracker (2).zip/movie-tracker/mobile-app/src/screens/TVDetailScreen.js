import React, { useEffect, useState } from 'react';
import { ActivityIndicator, FlatList, Image, Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import { getTvDetails, posterUrl } from '../services/tmdb';

export default function TVDetailScreen({ route, navigation }) {
  const { id } = route.params;
  const [show, setShow] = useState(null);

  useEffect(() => {
    getTvDetails(id).then(setShow);
  }, [id]);

  if (!show) {
    return (
      <View style={styles.loading}>
        <ActivityIndicator color="#fff" />
      </View>
    );
  }

  const cast = show.credits?.cast?.slice(0, 15) || [];
  const genres = (show.genres || []).map((g) => g.name).join(' · ');
  const seasons = (show.seasons || []).filter((s) => s.season_number > 0 || show.seasons.length === 1);

  return (
    <ScrollView style={styles.container}>
      <Image source={{ uri: posterUrl(show.backdrop_path, 'w780') }} style={styles.backdrop} />
      <View style={styles.body}>
        <Text style={styles.title}>{show.name}</Text>
        <Text style={styles.meta}>
          {show.first_air_date?.slice(0, 4)}
          {show.last_air_date && show.last_air_date.slice(0, 4) !== show.first_air_date?.slice(0, 4)
            ? `–${show.last_air_date.slice(0, 4)}` : ''}
          {' · '}{show.number_of_seasons} season{show.number_of_seasons !== 1 ? 's' : ''}
          {' · ⭐ '}{show.vote_average?.toFixed(1)}
        </Text>
        {genres ? <Text style={styles.genres}>{genres}</Text> : null}
        <Text style={styles.overview}>{show.overview}</Text>

        <Text style={styles.sectionTitle}>Seasons</Text>
        {seasons.map((season) => (
          <Pressable
            key={season.id}
            style={styles.seasonRow}
            onPress={() =>
              navigation.navigate('Season', {
                tvId: show.id,
                showName: show.name,
                seasonNumber: season.season_number,
                seasonName: season.name,
              })
            }
          >
            <Image source={{ uri: posterUrl(season.poster_path, 'w185') }} style={styles.seasonPoster} />
            <View style={styles.seasonInfo}>
              <Text style={styles.seasonName}>{season.name}</Text>
              <Text style={styles.seasonMeta}>{season.episode_count} episodes</Text>
            </View>
          </Pressable>
        ))}

        {cast.length > 0 && (
          <>
            <Text style={styles.sectionTitle}>Cast</Text>
            <FlatList
              data={cast}
              horizontal
              showsHorizontalScrollIndicator={false}
              keyExtractor={(item) => String(item.credit_id)}
              renderItem={({ item }) => (
                <View style={styles.castCard}>
                  <Image source={{ uri: posterUrl(item.profile_path, 'w185') }} style={styles.castPhoto} />
                  <Text style={styles.castName} numberOfLines={1}>{item.name}</Text>
                  <Text style={styles.castRole} numberOfLines={1}>{item.character}</Text>
                </View>
              )}
            />
          </>
        )}
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#000' },
  loading: { flex: 1, backgroundColor: '#000', justifyContent: 'center' },
  backdrop: { width: '100%', height: 220, backgroundColor: '#1c1c1e' },
  body: { padding: 16 },
  title: { color: '#fff', fontSize: 24, fontWeight: '700' },
  meta: { color: '#8e8e93', fontSize: 14, marginTop: 4 },
  genres: { color: '#8e8e93', fontSize: 13, marginTop: 4 },
  overview: { color: '#d1d1d6', fontSize: 15, lineHeight: 22, marginTop: 16 },
  sectionTitle: { color: '#fff', fontSize: 18, fontWeight: '600', marginTop: 24, marginBottom: 10 },
  seasonRow: { flexDirection: 'row', alignItems: 'center', marginBottom: 12 },
  seasonPoster: { width: 60, height: 90, borderRadius: 6, backgroundColor: '#1c1c1e' },
  seasonInfo: { marginLeft: 12 },
  seasonName: { color: '#fff', fontSize: 15, fontWeight: '500' },
  seasonMeta: { color: '#8e8e93', fontSize: 13, marginTop: 2 },
  castCard: { width: 90, marginRight: 12 },
  castPhoto: { width: 90, height: 120, borderRadius: 8, backgroundColor: '#1c1c1e' },
  castName: { color: '#fff', fontSize: 13, marginTop: 6, fontWeight: '500' },
  castRole: { color: '#8e8e93', fontSize: 12 },
});
