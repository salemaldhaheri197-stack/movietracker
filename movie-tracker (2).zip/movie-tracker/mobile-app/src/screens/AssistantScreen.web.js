import React from 'react';
import { StyleSheet, Text, View } from 'react-native';

// Metro picks this file automatically on web builds (AssistantScreen.web.js
// beats AssistantScreen.native.js there), so the ElevenLabs React Native SDK
// — which is WebRTC/native-only and has no web build — never gets bundled
// into the website at all.
export default function AssistantScreen() {
  return (
    <View style={styles.container}>
      <Text style={styles.title}>Voice Assistant</Text>
      <Text style={styles.body}>
        The voice assistant uses ElevenLabs' native mobile SDK and isn't
        available in the browser version. Open this app on iOS or Android
        to talk to it.
      </Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#000', justifyContent: 'center', alignItems: 'center', padding: 24 },
  title: { color: '#fff', fontSize: 22, fontWeight: '700', marginBottom: 12 },
  body: { color: '#8e8e93', textAlign: 'center', lineHeight: 20, maxWidth: 360 },
});
