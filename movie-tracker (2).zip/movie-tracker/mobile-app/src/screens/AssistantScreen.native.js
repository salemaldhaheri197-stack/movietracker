import React, { useState } from 'react';
import { Pressable, StyleSheet, Text, View } from 'react-native';
import { ConversationProvider, useConversationControls, useConversationStatus } from '@elevenlabs/react-native';
import { useAuth } from '../context/AuthContext';
import { useWatched } from '../context/WatchedContext';
import * as api from '../services/api';
import { buildAgentTools } from '../tools/agentTools';

// ---------------------------------------------------------------------------
// Setup needed before this file will run (one-time, requires network access):
//
//   npx expo install @elevenlabs/react-native @livekit/react-native \
//     @livekit/react-native-webrtc @config-plugins/react-native-webrtc \
//     livekit-client @livekit/react-native-expo-plugin
//   npx expo run:ios   (or: npx expo run:android)
//
// This SDK uses WebRTC, so it needs a custom dev build — it will NOT run
// inside plain Expo Go. Everything else in this app still will.
//
// Your ElevenLabs agent is set up as a PRIVATE agent, so the app never
// touches your secret API key directly — it asks your own PHP backend
// (backend/elevenlabs_token.php) for a short-lived conversation token,
// which is the pattern ElevenLabs documents for client apps:
// https://elevenlabs.io/docs/agents-platform/libraries/java-script
//
// Before this works you still need to:
//   1. Create your agent at https://elevenlabs.io/app/conversational-ai
//   2. Paste its Agent ID into backend/config.php as ELEVENLABS_AGENT_ID
//   3. In the agent's dashboard, set it to require authorization (private)
// ---------------------------------------------------------------------------

function AssistantInner() {
  const { token } = useAuth();
  const watched = useWatched();
  const { startSession, endSession } = useConversationControls();
  const { status } = useConversationStatus();
  const [error, setError] = useState('');

  async function handleStart() {
    setError('');
    try {
      const { token: conversationToken } = await api.getElevenLabsToken(token);
      await startSession({
        conversationToken,
        connectionType: 'webrtc',
        clientTools: buildAgentTools({ token, watched }),
      });
    } catch (e) {
      setError(e.message);
    }
  }

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Voice Assistant</Text>
      <Text style={styles.status}>Status: {status}</Text>
      {error ? <Text style={styles.error}>{error}</Text> : null}
      <Pressable
        style={styles.button}
        onPress={status === 'connected' ? endSession : handleStart}
      >
        <Text style={styles.buttonText}>{status === 'connected' ? 'End' : 'Start Talking'}</Text>
      </Pressable>
    </View>
  );
}

export default function AssistantScreen() {
  return (
    <ConversationProvider>
      <AssistantInner />
    </ConversationProvider>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#000', justifyContent: 'center', alignItems: 'center', padding: 24 },
  title: { color: '#fff', fontSize: 22, fontWeight: '700', marginBottom: 12 },
  status: { color: '#8e8e93', marginBottom: 20 },
  error: { color: '#ff453a', marginBottom: 12, textAlign: 'center' },
  button: { backgroundColor: '#e50914', borderRadius: 10, paddingVertical: 12, paddingHorizontal: 24 },
  buttonText: { color: '#fff', fontWeight: '600', fontSize: 16 },
});
