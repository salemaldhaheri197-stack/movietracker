import React, { useState } from 'react';
import { FlatList, Image, Pressable, StyleSheet, Text, TextInput, View } from 'react-native';
import { posterUrl, searchMulti } from '../services/tmdb';

export default function SearchScreen({ navigation }) {
  const [query, setQuery] = useState('');
  const [results, setResults] = useState([]);
  const [searching, setSearching] = useState(false);

  async function runSearch(text) {
    setQuery(text);
    if (text.trim().length < 2) {
      setResults([]);
      return;
    }
    setSearching(true);
    try {
      const data = await searchMulti(text.trim());
      setResults((data.results || []).filter((r) => r.media_type === 'movie' || r.media_type === 'tv'));
    } finally {
      setSearching(false);
    }
  }

  function openItem(item) {
    if (item.media_type === 'tv') {
      navigation.navigate('TVDetail', { id: item.id });
    } else {
      navigation.navigate('MovieDetail', { id: item.id });
    }
  }

  return (
    <View style={styles.container}>
      <TextInput
        style={styles.input}
        placeholder="Search movies & TV shows"
        placeholderTextColor="#8e8e93"
        value={query}
        onChangeText={runSearch}
        autoCapitalize="none"
      />
      <FlatList
        data={results}
        keyExtractor={(item) => `${item.media_type}-${item.id}`}
        renderItem={({ item }) => (
          <Pressable style={styles.resultRow} onPress={() => openItem(item)}>
            <Image source={{ uri: posterUrl(item.poster_path, 'w92') }} style={styles.thumb} />
            <View style={styles.resultInfo}>
              <Text style={styles.resultTitle}>{item.title || item.name}</Text>
              <Text style={styles.resultMeta}>
                {item.media_type === 'tv' ? 'TV Show' : 'Movie'} ·{' '}
                {(item.release_date || item.first_air_date || '').slice(0, 4) || 'Unknown'}
              </Text>
            </View>
          </Pressable>
        )}
        ListEmptyComponent={
          !searching && query.length >= 2 ? <Text style={styles.empty}>No results</Text> : null
        }
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#000', paddingTop: 8 },
  input: {
    backgroundColor: '#1c1c1e', color: '#fff', borderRadius: 10,
    padding: 12, margin: 16, fontSize: 16,
  },
  resultRow: { flexDirection: 'row', paddingHorizontal: 16, paddingVertical: 8, alignItems: 'center' },
  thumb: { width: 46, height: 69, borderRadius: 6, backgroundColor: '#1c1c1e' },
  resultInfo: { marginLeft: 12, flex: 1 },
  resultTitle: { color: '#fff', fontSize: 16, fontWeight: '500' },
  resultMeta: { color: '#8e8e93', fontSize: 13, marginTop: 2 },
  empty: { color: '#8e8e93', textAlign: 'center', marginTop: 40 },
});
