import { TMDB_API_KEY, TMDB_BASE_URL, TMDB_IMAGE_BASE } from '../config';

async function tmdbGet(path, params = {}) {
  const query = new URLSearchParams({ api_key: TMDB_API_KEY, ...params }).toString();
  const res = await fetch(`${TMDB_BASE_URL}${path}?${query}`);
  if (!res.ok) {
    throw new Error(`TMDb request failed: ${res.status}`);
  }
  return res.json();
}

export function posterUrl(path, size = 'w342') {
  return path ? `${TMDB_IMAGE_BASE}/${size}${path}` : null;
}

// Trending movies + TV shows for the Home screen
export function getTrending(mediaType = 'all', window = 'day') {
  return tmdbGet(`/trending/${mediaType}/${window}`);
}

// Search movies, TV shows, and people together
export function searchMulti(query, page = 1) {
  return tmdbGet('/search/multi', { query, page, include_adult: false });
}

// Full movie details: overview, runtime, genres, cast/crew, videos
export function getMovieDetails(id) {
  return tmdbGet(`/movie/${id}`, { append_to_response: 'credits,videos,recommendations' });
}

// Full TV details: overview, seasons list, cast/crew
export function getTvDetails(id) {
  return tmdbGet(`/tv/${id}`, { append_to_response: 'credits,videos,recommendations' });
}

// Episodes for one season of a show
export function getSeasonDetails(tvId, seasonNumber) {
  return tmdbGet(`/tv/${tvId}/season/${seasonNumber}`);
}

// A single episode, with its own guest cast/crew
export function getEpisodeDetails(tvId, seasonNumber, episodeNumber) {
  return tmdbGet(`/tv/${tvId}/season/${seasonNumber}/episode/${episodeNumber}`, {
    append_to_response: 'credits',
  });
}

export function getPersonDetails(id) {
  return tmdbGet(`/person/${id}`, { append_to_response: 'combined_credits' });
}
