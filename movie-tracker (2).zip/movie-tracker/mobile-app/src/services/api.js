import { BACKEND_URL } from '../config';

async function request(path, { method = 'GET', token, body } = {}) {
  const headers = { 'Content-Type': 'application/json' };
  if (token) headers.Authorization = `Bearer ${token}`;

  const res = await fetch(`${BACKEND_URL}${path}`, {
    method,
    headers,
    body: body ? JSON.stringify(body) : undefined,
  });

  const data = await res.json().catch(() => ({}));
  if (!res.ok) {
    throw new Error(data.error || `Request failed: ${res.status}`);
  }
  return data;
}

export function register(email, password) {
  return request('/register.php', { method: 'POST', body: { email, password } });
}

export function login(email, password) {
  return request('/login.php', { method: 'POST', body: { email, password } });
}

export function getWatched(token) {
  return request('/watched_list.php', { token });
}

// Mints a short-lived ElevenLabs conversation token via our own backend —
// the app never sees the ElevenLabs secret API key.
export function getElevenLabsToken(token) {
  return request('/elevenlabs_token.php', { token });
}

export function setMovieWatched(token, movie, watched) {
  return request('/watched_toggle.php', {
    method: 'POST',
    token,
    body: {
      type: 'movie',
      action: watched ? 'add' : 'remove',
      tmdb_id: movie.id,
      title: movie.title,
      poster_path: movie.poster_path,
    },
  });
}

export function setEpisodeWatched(token, { tvId, showName, seasonNumber, episodeNumber }, watched) {
  return request('/watched_toggle.php', {
    method: 'POST',
    token,
    body: {
      type: 'episode',
      action: watched ? 'add' : 'remove',
      tv_id: tvId,
      show_name: showName,
      season_number: seasonNumber,
      episode_number: episodeNumber,
    },
  });
}
