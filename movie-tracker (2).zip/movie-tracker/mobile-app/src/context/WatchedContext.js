import React, { createContext, useContext, useCallback, useEffect, useState } from 'react';
import * as api from '../services/api';
import { useAuth } from './AuthContext';

const WatchedContext = createContext(null);

function episodeKey(tvId, season, episode) {
  return `${tvId}-${season}-${episode}`;
}

export function WatchedProvider({ children }) {
  const { token } = useAuth();
  const [movies, setMovies] = useState([]); // full rows, for the Watchlist screen
  const [episodeSet, setEpisodeSet] = useState(new Set()); // fast lookup for "watched?" checks
  const [episodes, setEpisodes] = useState([]);

  const refresh = useCallback(async () => {
    if (!token) {
      setMovies([]);
      setEpisodes([]);
      setEpisodeSet(new Set());
      return;
    }
    const data = await api.getWatched(token);
    setMovies(data.movies || []);
    setEpisodes(data.episodes || []);
    setEpisodeSet(new Set((data.episodes || []).map((e) => episodeKey(e.tv_id, e.season_number, e.episode_number))));
  }, [token]);

  useEffect(() => {
    refresh();
  }, [refresh]);

  function isMovieWatched(tmdbId) {
    return movies.some((m) => m.tmdb_id === tmdbId);
  }

  function isEpisodeWatched(tvId, season, episode) {
    return episodeSet.has(episodeKey(tvId, season, episode));
  }

  async function toggleMovie(movie) {
    const nextWatched = !isMovieWatched(movie.id);
    await api.setMovieWatched(token, movie, nextWatched);
    await refresh();
  }

  async function toggleEpisode({ tvId, showName, seasonNumber, episodeNumber }) {
    const nextWatched = !isEpisodeWatched(tvId, seasonNumber, episodeNumber);
    await api.setEpisodeWatched(token, { tvId, showName, seasonNumber, episodeNumber }, nextWatched);
    await refresh();
  }

  return (
    <WatchedContext.Provider
      value={{ movies, episodes, isMovieWatched, isEpisodeWatched, toggleMovie, toggleEpisode, refresh }}
    >
      {children}
    </WatchedContext.Provider>
  );
}

export function useWatched() {
  return useContext(WatchedContext);
}
