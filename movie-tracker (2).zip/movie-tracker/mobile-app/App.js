import React from 'react';
import { StatusBar } from 'expo-status-bar';
import { AuthProvider } from './src/context/AuthContext';
import { WatchedProvider } from './src/context/WatchedContext';
import RootNavigator from './src/navigation';

export default function App() {
  return (
    <AuthProvider>
      <WatchedProvider>
        <StatusBar style="light" />
        <RootNavigator />
      </WatchedProvider>
    </AuthProvider>
  );
}
