<?php
require_once __DIR__ . '/config.php';
send_cors_headers();

$body = json_body();
$email = trim($body['email'] ?? '');
$password = $body['password'] ?? '';

$conn = get_db();

$stmt = $conn->prepare('SELECT id, email, password_hash FROM movietracker_users WHERE email = ?');
$stmt->bind_param('s', $email);
$stmt->execute();
$user = $stmt->get_result()->fetch_assoc();

if (!$user || !password_verify($password, $user['password_hash'])) {
    http_response_code(401);
    echo json_encode(['error' => 'Invalid email or password']);
    exit;
}

// Rotate the token on each login
$token = bin2hex(random_bytes(32));
$stmt = $conn->prepare('UPDATE movietracker_users SET token = ? WHERE id = ?');
$stmt->bind_param('si', $token, $user['id']);
$stmt->execute();

echo json_encode([
    'token' => $token,
    'user' => ['id' => $user['id'], 'email' => $user['email']],
]);
