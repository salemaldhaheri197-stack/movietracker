<?php
// Copy this file to config.php and fill in real values there.
// config.php is gitignored — it never gets committed.
define('DB_HOST', 'your-db-host');
define('DB_NAME', 'your-db-name');
define('DB_USER', 'your-db-user');
define('DB_PASS', 'your-db-password');

// ElevenLabs Conversational AI — server-side only, never send this to the app.
define('ELEVENLABS_API_KEY', 'your-elevenlabs-api-key');
define('ELEVENLABS_AGENT_ID', 'your-agent-id');

function get_db() {
    $conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
    if ($conn->connect_error) {
        http_response_code(500);
        die(json_encode(['error' => 'Database connection failed']));
    }
    return $conn;
}

// CORS + JSON headers for every endpoint
function send_cors_headers() {
    header('Access-Control-Allow-Origin: *');
    header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
    header('Access-Control-Allow-Headers: Content-Type, Authorization');
    header('Content-Type: application/json');
    if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
        http_response_code(204);
        exit;
    }
}

function json_body() {
    return json_decode(file_get_contents('php://input'), true) ?? [];
}
