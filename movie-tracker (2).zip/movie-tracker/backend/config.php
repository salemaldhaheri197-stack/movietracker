<?php
// Fill these in with your AwardSpace / atwebpages.com MySQL credentials
// (same pattern as your Employees and Meetings app databases)
define('DB_HOST', 'fdb1028.awardspace.net');
define('DB_NAME', '4786926_employees');
define('DB_USER', '4786926_employees');
define('DB_PASS', 'Ain12312312k');

// ElevenLabs Conversational AI — server-side only, never send this to the app.
define('ELEVENLABS_API_KEY', 'sk_d9c1c59624e737c2329fa49fa4373fadadd35cd950c73180');
// Fill this in once you've created your agent in the ElevenLabs dashboard.
define('ELEVENLABS_AGENT_ID', '');

function get_db() {
    $conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
    if ($conn->connect_error) {
        http_response_code(500);
        die(json_encode(['error' => 'Database connection failed']));
    }
    return $conn;
}

// CORS + JSON headers for every endpoint
function send_cors_headers() {
    header('Access-Control-Allow-Origin: *');
    header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
    header('Access-Control-Allow-Headers: Content-Type, Authorization');
    header('Content-Type: application/json');
    if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
        http_response_code(204);
        exit;
    }
}

function json_body() {
    return json_decode(file_get_contents('php://input'), true) ?? [];
}
