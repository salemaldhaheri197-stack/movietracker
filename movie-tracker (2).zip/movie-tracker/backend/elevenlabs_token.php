<?php
// Returns a short-lived WebRTC conversation token for the ElevenLabs agent.
// The app calls this (with its own login token) instead of ever seeing your
// ElevenLabs API key. See:
// https://elevenlabs.io/docs/agents-platform/libraries/java-script#private-agents
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/auth_helper.php';
send_cors_headers();

$conn = get_db();
require_auth($conn); // only your app's logged-in users can mint a token

if (!ELEVENLABS_AGENT_ID) {
    http_response_code(500);
    echo json_encode(['error' => 'ELEVENLABS_AGENT_ID is not set in config.php yet']);
    exit;
}

$url = 'https://api.elevenlabs.io/v1/convai/conversation/token?agent_id=' . urlencode(ELEVENLABS_AGENT_ID);

$ch = curl_init($url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_HTTPHEADER, ['xi-api-key: ' . ELEVENLABS_API_KEY]);
$response = curl_exec($ch);
$status = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

if ($status !== 200) {
    http_response_code(502);
    echo json_encode(['error' => 'Failed to get a token from ElevenLabs', 'details' => $response]);
    exit;
}

$data = json_decode($response, true);
echo json_encode(['token' => $data['token'] ?? null]);
