<?php
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/auth_helper.php';
send_cors_headers();

$conn = get_db();
$user = require_auth($conn);
$body = json_body();

$type = $body['type'] ?? '';       // 'movie' | 'episode'
$action = $body['action'] ?? '';   // 'add' | 'remove'

if (!in_array($type, ['movie', 'episode']) || !in_array($action, ['add', 'remove'])) {
    http_response_code(400);
    echo json_encode(['error' => 'Invalid type or action']);
    exit;
}

if ($type === 'movie') {
    $tmdbId = (int) ($body['tmdb_id'] ?? 0);
    $title = $body['title'] ?? '';
    $poster = $body['poster_path'] ?? '';

    if ($action === 'add') {
        $stmt = $conn->prepare(
            'INSERT INTO movietracker_watched_movies (user_id, tmdb_id, title, poster_path)
             VALUES (?, ?, ?, ?)
             ON DUPLICATE KEY UPDATE watched_at = CURRENT_TIMESTAMP'
        );
        $stmt->bind_param('iiss', $user['id'], $tmdbId, $title, $poster);
    } else {
        $stmt = $conn->prepare('DELETE FROM movietracker_watched_movies WHERE user_id = ? AND tmdb_id = ?');
        $stmt->bind_param('ii', $user['id'], $tmdbId);
    }
    $stmt->execute();
} else {
    $tvId = (int) ($body['tv_id'] ?? 0);
    $season = (int) ($body['season_number'] ?? 0);
    $episode = (int) ($body['episode_number'] ?? 0);
    $showName = $body['show_name'] ?? '';

    if ($action === 'add') {
        $stmt = $conn->prepare(
            'INSERT INTO movietracker_watched_episodes (user_id, tv_id, show_name, season_number, episode_number)
             VALUES (?, ?, ?, ?, ?)
             ON DUPLICATE KEY UPDATE watched_at = CURRENT_TIMESTAMP'
        );
        $stmt->bind_param('iisii', $user['id'], $tvId, $showName, $season, $episode);
    } else {
        $stmt = $conn->prepare(
            'DELETE FROM movietracker_watched_episodes WHERE user_id = ? AND tv_id = ? AND season_number = ? AND episode_number = ?'
        );
        $stmt->bind_param('iiii', $user['id'], $tvId, $season, $episode);
    }
    $stmt->execute();
}

echo json_encode(['success' => true]);
