<?php
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/auth_helper.php';
send_cors_headers();

$conn = get_db();
$user = require_auth($conn);

$movies = [];
$stmt = $conn->prepare('SELECT tmdb_id, title, poster_path, watched_at FROM movietracker_watched_movies WHERE user_id = ? ORDER BY watched_at DESC');
$stmt->bind_param('i', $user['id']);
$stmt->execute();
$result = $stmt->get_result();
while ($row = $result->fetch_assoc()) {
    $movies[] = $row;
}

$episodes = [];
$stmt = $conn->prepare('SELECT tv_id, show_name, season_number, episode_number, watched_at FROM movietracker_watched_episodes WHERE user_id = ? ORDER BY tv_id, season_number, episode_number');
$stmt->bind_param('i', $user['id']);
$stmt->execute();
$result = $stmt->get_result();
while ($row = $result->fetch_assoc()) {
    $episodes[] = $row;
}

echo json_encode(['movies' => $movies, 'episodes' => $episodes]);
