-- Movie Tracker backend schema
-- Import this into your MySQL database (same pattern as your other atwebpages.com projects)

CREATE TABLE IF NOT EXISTS movietracker_users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  email VARCHAR(191) NOT NULL UNIQUE,
  password_hash VARCHAR(255) NOT NULL,
  token VARCHAR(64) NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS movietracker_watched_movies (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NOT NULL,
  tmdb_id INT NOT NULL,
  title VARCHAR(255),
  poster_path VARCHAR(255),
  watched_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY uniq_user_movie (user_id, tmdb_id),
  CONSTRAINT fk_wm_user FOREIGN KEY (user_id) REFERENCES movietracker_users(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS movietracker_watched_episodes (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NOT NULL,
  tv_id INT NOT NULL,
  show_name VARCHAR(255),
  season_number INT NOT NULL,
  episode_number INT NOT NULL,
  watched_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY uniq_user_episode (user_id, tv_id, season_number, episode_number),
  CONSTRAINT fk_we_user FOREIGN KEY (user_id) REFERENCES movietracker_users(id) ON DELETE CASCADE
);
