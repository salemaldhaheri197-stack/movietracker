<?php
require_once __DIR__ . '/config.php';
send_cors_headers();

$body = json_body();
$email = trim($body['email'] ?? '');
$password = $body['password'] ?? '';

if (!$email || !$password) {
    http_response_code(400);
    echo json_encode(['error' => 'Email and password are required']);
    exit;
}

$conn = get_db();

$stmt = $conn->prepare('SELECT id FROM movietracker_users WHERE email = ?');
$stmt->bind_param('s', $email);
$stmt->execute();
if ($stmt->get_result()->fetch_assoc()) {
    http_response_code(409);
    echo json_encode(['error' => 'An account with that email already exists']);
    exit;
}

$hash = password_hash($password, PASSWORD_DEFAULT);
$token = bin2hex(random_bytes(32));

$stmt = $conn->prepare('INSERT INTO movietracker_users (email, password_hash, token) VALUES (?, ?, ?)');
$stmt->bind_param('sss', $email, $hash, $token);
$stmt->execute();

echo json_encode([
    'token' => $token,
    'user' => ['id' => $conn->insert_id, 'email' => $email],
]);
