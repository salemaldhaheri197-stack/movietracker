// ---- Fill these in ----

// Get a free key at https://www.themoviedb.org/settings/api
export const TMDB_API_KEY = 'YOUR_TMDB_API_KEY';

// Point this at your PHP backend (backend/ folder in this project),
// deployed the same way as your other atwebpages.com projects.
export const BACKEND_URL = 'https://yourdomain.atwebpages.com/api';

// Create an agent at https://elevenlabs.io/app/conversational-ai and paste its ID here
// once you wire up src/screens/AssistantScreen.js
export const ELEVENLABS_AGENT_ID = '';

// ---- Fixed values, no need to touch ----
export const TMDB_BASE_URL = 'https://api.themoviedb.org/3';
export const TMDB_IMAGE_BASE = 'https://image.tmdb.org/t/p';
export const POSTER_SIZE = 'w342';
export const BACKDROP_SIZE = 'w780';
export const PROFILE_SIZE = 'w185';
